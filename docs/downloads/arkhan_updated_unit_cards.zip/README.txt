43 distinct refreshed unit-card PNGs at 60 x 130 pixels, all using the same four-pixel smooth edge fade. Duplicate uploads are omitted.
The in-game versions are under ui/units/icons in the mod pack.
