Eleven supplied filenames are preserved as PNG exports at 60 x 130 pixels with soft transparent edges. The three (1) files were byte-identical uploads and use the same finished artwork as their corresponding originals.

Game path mapping:
wh2_dlc09_tmb_sepulchral_stalkers_ror.png -> ui/units/icons/xereus_tmb_mon_sepulchral_stalkers.png
wh2_dlc09_tmb_fell_bats.png -> ui/units/icons/wh2_dlc09_tmb_fell_bats.png
wh2_dlc09_tmb_dire_wolves.png -> ui/units/icons/wh2_dlc09_tmb_dire_wolves.png
xereus_tmb_cav_skeleton_horsemen_archers.png -> ui/units/icons/xereus_tmb_cav_skeleton_horsemen_archers.png
xereus_tmb_cav_nehekhara_horsemen.png -> ui/units/icons/xereus_tmb_cav_nehekhara_horsemen.png
xereus_tmb_cav_skeleton_horsemen_0.png -> ui/units/icons/xereus_tmb_skeleton_horsemen.png
xereus_tmb_veh_skeleton_archer_chariot_0.png -> ui/units/icons/xereus_tmb_skeleton_chariot_archers.png
xereus_tmb_veh_skeleton_chariot_0.png -> ui/units/icons/xereus_tmb_skeleton_chariot.png
xereus_tmb_cav_skeleton_horsemen_archers(1).png -> ui/units/icons/xereus_tmb_cav_skeleton_horsemen_archers.png
xereus_tmb_cav_nehekhara_horsemen(1).png -> ui/units/icons/xereus_tmb_cav_nehekhara_horsemen.png
xereus_tmb_cav_skeleton_horsemen_0(1).png -> ui/units/icons/xereus_tmb_skeleton_horsemen.png