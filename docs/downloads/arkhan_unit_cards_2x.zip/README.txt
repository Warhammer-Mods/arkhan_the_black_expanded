43 unit infopics at 120 x 260 pixels, using the exact alpha channel from the supplied reference. Place these matching filenames in ui/units/infopics. Files in ui/units/icons stay unchanged.
